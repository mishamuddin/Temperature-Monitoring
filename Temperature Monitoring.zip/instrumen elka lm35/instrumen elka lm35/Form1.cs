﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace instrumen_elka_lm35
{
    public partial class Form1 : Form
    {
        delegate void SetTextCallback(String text);
        public System.IO.Ports.SerialPort ser_port;
        string sensor1;
        string sensor2;
        string sensor3;
        public Form1()
        {
            InitializeComponent();
            foreach(String s in System.IO.Ports.SerialPort.GetPortNames())
            {
                comboBox1.Items.Add(s);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ser_port = new System.IO.Ports.SerialPort(comboBox1.Text, 9600,
            System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
            try
            {
                ser_port.Open();
                button2.Enabled = true;
                button1.Enabled = false;
                richTextBox1.AppendText("Connected\n");
                ser_port.DataReceived += new SerialDataReceivedEventHandler(ser_port_DataReceived);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ser_port.IsOpen)
            {
                ser_port.Close();
                button2.Enabled = false;
                button1.Enabled = true;
                richTextBox1.AppendText("Disconnected\n");

            }
        }

        private void SetText(String text)
        {
            if (this.richTextBox1.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.richTextBox1.Text += text+"\r\n";
                
            }
        }

        String data;
        String dataIN;
        private void ser_port_DataReceived(Object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            data = ser_port.ReadLine();
            dataIN += data + "\r\n";
            SetText(dataIN.ToString());
            this.Invoke(new EventHandler(showdata));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Boolean data_sensor = timer1.Enabled;
            timer1.Enabled = !data_sensor;
            
        }

        SignalDataReceivedAll LocY;
        private void showdata(object sender, EventArgs e)
        {
            try
            {
                //richTextBox1.Text = data;
                char[] sparator = { ';' };
                String[] bagi = data.Split(sparator, StringSplitOptions.RemoveEmptyEntries);
                int jumlah_data = bagi.Length;
                if (jumlah_data >3)
                {
                    sensor1 = bagi[0];
                    sensor2 = bagi[1];
                    sensor3 = bagi[2];

                    LocY.data1 = Int32.Parse(sensor1);
                    LocY.data2 = Int32.Parse(sensor2);
                    LocY.data3 = Int32.Parse(sensor3);
                    
                    //richTextBox1.Text += bagi[0] + bagi[1] + bagi[2] + "\r\n";

                    textBox1.Text = bagi[0];
                    textBox2.Text = bagi[1];
                    textBox3.Text = bagi[2];
                    chart(LocY);

                }
                else
                {
                    //sensor1 = bagi[0];
                    //sensor2 = bagi[1];
                    //sensor3 = bagi[2];

                    //richTextBox1.Text += bagi[0] + bagi[1] + bagi[2] + "\r\n";
                    //LocY.data1 = Int32.Parse(sensor1);

                    textBox1.Text = sensor1.ToString();
                    textBox2.Text = bagi[1];
                    textBox3.Text = bagi[2];
                    //chart(LocY);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        delegate void SetLocXYCallback(SignalDataReceivedAll Z);
        struct SignalDataReceivedAll
        {
            public int data1;
            public int data2;
            public int data3;
            
        }

        int LocX;
        private void chart(SignalDataReceivedAll Z)
        {
            if (this.chart1.InvokeRequired)
            {
                SetLocXYCallback XY = new SetLocXYCallback(chart);
                this.Invoke(XY, new object[] { Z });
            }
            else
            {
                LocX++;
                chart1.Series["Temperature"].Points.AddXY(LocX, Z.data1);
                chart1.Series["Temperature"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
                chart1.Series["Temperature"].Color = Color.Red;

                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Size = 100;
                if (LocX > 100)
                {
                    chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Position = chart1.ChartAreas["ChartArea1"].AxisX.Maximum - 100;
                }
                else
                {
                    chart1.ChartAreas[0].AxisX.ScaleView.Position = 0;
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
